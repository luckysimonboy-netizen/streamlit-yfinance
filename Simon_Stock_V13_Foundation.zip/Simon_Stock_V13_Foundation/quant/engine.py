import numpy as np,pandas as pd
def quant_snapshot(df):
    c=df["Close"].astype(float);d=pd.DataFrame(index=df.index);d["Close"]=c
    for w in [20,50,100,200]:d[f"MA{w}"]=c.rolling(w).mean()
    e12=c.ewm(span=12,adjust=False).mean();e26=c.ewm(span=26,adjust=False).mean()
    d["MACD"]=e12-e26;d["Signal"]=d["MACD"].ewm(span=9,adjust=False).mean()
    delta=c.diff();gain=delta.clip(lower=0).rolling(14).mean();loss=-delta.clip(upper=0).rolling(14).mean()
    rs=gain/loss.replace(0,np.nan);d["RSI"]=100-100/(1+rs);d["Volatility"]=c.pct_change().rolling(20).std()*np.sqrt(252)
    d["MOM3M"]=c/c.shift(63)-1;d["Drawdown"]=c/c.cummax()-1;x=d.iloc[-1];score=50
    for w,pts in [(20,6),(50,8),(200,12)]:
        ma=x.get(f"MA{w}",np.nan)
        if np.isfinite(ma):score+=pts if x["Close"]>ma else -pts
    r=x.get("RSI",np.nan)
    if np.isfinite(r):score+=8 if 42<=r<=65 else 3 if r<30 else -10 if r>75 else -3
    score+=7 if x.get("MACD",0)>x.get("Signal",0) else -6
    m=x.get("MOM3M",0);score+=8 if m>.15 else 4 if m>0 else -8 if m<-.15 else -3
    return {"price":float(x["Close"]),"rsi":float(r) if np.isfinite(r) else np.nan,"volatility":float(x["Volatility"]) if np.isfinite(x["Volatility"]) else np.nan,"mom3m":float(m),"score":float(np.clip(score,0,100)),"table":d.tail(60).reset_index()}
